/*
Author: Alex Novitchkov
File: main.cpp, the controller of the program
CS202-01 asgn2.1
Special compiler options: -c -o
Date: 1/30/20

Contains functions that control and manipulate the program
 */

#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include "quiz.h"

using namespace std;

/*
   Calculates the percentage correct based on the input

   @param correct, how many questions the user got correct
   @param total, how may total questions were there

   @return percentage correct as a float
 */

float calculatePercentage(int correct, int total);

/*
   Displays the users results of how well they did on the quiz

   @param correct, how many questions the user got correct
   @param total, how many total questions were there
   @param percentage, percent correct
 */
void finalMessage(int correct, int total, float percentage);

/*----------------------------------*/
int main(int argc, char* argv[])
{
	string dataFileName;
	Quiz aQuiz;
	int numCorrect;
	int totalQuestions;
	bool fileOpened;
	float percentage;

	if (argc < 2)
	{
		cout << "ERROR! Not enough arguments. 2 must be given!";
		cout << endl;
	}
	else if (argc > 2)
	{
		string thirdArgument = argv[2];

		if (argc == 3 && thirdArgument == "-d")
		{
			cout << endl;
			cout << "Hope your brain's warmed up, ";
			cout << "it's Quiz Time!!!" << endl;
			cout << "After each aswer is displayed, ";
			cout << "press enter to see the next question." << endl;

			dataFileName = argv[1];
			fileOpened = aQuiz.loadQuestions(dataFileName);

			if (fileOpened)
			{
				aQuiz.dumpQuestions();
			}
		}
		else
		{

			cout << "ERROR! Too many arguments. ";
			cout << "Only 2 must be given!";
			cout << endl;
		}
	}
	else
	{
		dataFileName = argv[1];

		fileOpened = aQuiz.loadQuestions(dataFileName);

		if (fileOpened)
		{
			cout << endl;
			cout << "Hope your brain's warmed up, ";
			cout << "it's Quiz Time!!!" << endl;
			cout << "After each aswer is displayed, ";
			cout << "press enter to see the next question." << endl;

			numCorrect = aQuiz.deliverQuiz();

			totalQuestions = aQuiz.getLength();

			percentage = calculatePercentage(numCorrect, totalQuestions);

			finalMessage(numCorrect, totalQuestions, percentage);
		}
	}

	return 1;
}

/*---------------------------------------------------*/
float calculatePercentage(int correct, int total)
{
	float percentageCorrect;

	/* doing floating point arithmetic rather than integer */
	percentageCorrect = ((float) correct / (float) total) * 100.0;

	return percentageCorrect;
}

/*-----------------------------------------------------------*/
void finalMessage(int correct, int total, float percentage)
{
	/* only for digits allowed for percentage */
	cout << "You got " << correct << " of "
		<< total << " correct: "
		<< setprecision(4) << percentage << "%.";

	if (percentage < 60)
	{
		cout << "   Better study more!" << endl;
	}
	else
	{
		cout << "   Great work!" << endl;
	}
}
