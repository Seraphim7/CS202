#ifndef QUESTION_H
#define QUESTION_H

/*
Author: Alex Novitchkov
File: question.h, contains all the "outline" of class Question
CS202-01 asgn2.1
Special compiler options: -c -o
Date: 1/30/20

This file contains function prototypes and
instance variables of the Question class.
 */

#include <string>

using namespace std;

class Question
{
	public:
		/*
		   Initializes the private member variables to '\0' and false
		 */
		Question();

		/*
		   Prints the question to the cout
		 */
		void showQuestion();

		/*
		   Sets the contents of question based on the input text

		   @param questionText, input text
		 */
		void setQuestion(string questionText);

		/*
		   Sets the contents of answer based on the input text

		   @param answerText, input text
		 */
		void setAnswer(string answerText);

		/*
		   Checks the answer to see whether it is correct or not

		   @param checkAnswer, text to compare against answerText
		   @return bool whether the strings are equivelant or not
		 */
		bool checkAnswer(string givenAnswer);

		/*
		   Prints the answer to cout
		 */
		void showAnswer();

		/*
		   Marks instance variable correct to correct
		 */
		void markCorrect();

		/*
		   Returns the question

		   @return string questionText
		 */
		string getQuestion();

		/*
		   Returns the answer

		   @return string answerText
		 */
		string getAnswer();
	private:
		string questionText;
		string answerText;
		bool correct;
};

#endif
