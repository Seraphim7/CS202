/*
Author: Alex Novitchkov
File: quiz.cpp, implementation of the functions defined in the Quiz class
CS202-01 asgn2.1
Special compiler options: -c -o
Date: 1/30/20

implementation of all the Quiz class functions
including deliverQuiz and loadQuestions
 */

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include "quiz.h"
#include "question.h"

using namespace std;

/*-----------------------*/
Quiz::Quiz()
{

}

/*---------------------------------------------*/
bool Quiz::loadQuestions(string dataFileName)
{
	ifstream fin;
	string tmp;
	Question newQuestion;
	string fileLine;

	fin.open(dataFileName.c_str()); // has to take in a cString equivelant

	int count;

	if (fin.is_open())
	{
		while (getline(fin, fileLine))
		{
			count = 0;

			/* stringParse acts like cin */
			istringstream stringParse(fileLine);

			while (getline(stringParse, tmp, '|'))
			{
				count++;

				/*
				   doing seperate calculations,
				   for now. I will improve on this later.
				 */
				if (count == 3)
				{
					newQuestion.setQuestion(tmp);
				}
				else if (count == 4)
				{
					newQuestion.setAnswer(tmp);
					questions.push_back(newQuestion);
				}
			}
		}
		fin.close();
	}
	else
	{
		cout << "ERROR while opening file: " << dataFileName << endl;
		return false;
	}

	return true;
}

/*------------------------------*/
void Quiz::dumpQuestions()
{
	if (questions.empty())
	{
		cout << "No questions given" << endl;
	}
	else
	{
		for (unsigned int i = 0; i < questions.size(); i++)
		{
			cout << endl;
			questions[i].showQuestion();
			questions[i].showAnswer();
		}
	}
}

/*-------------------------------*/
int Quiz::deliverQuiz()
{
	int numCorrect = 0;
	int total = questions.size();
	int i = 0;
	string givenAnswer;
	bool correct;
	string controlString;

	cout << endl;

	while (i < total)
	{
		questions[i].showQuestion();

		getline(cin, givenAnswer);

		correct = questions[i].checkAnswer(givenAnswer);

		if (correct)
		{
			questions[i].markCorrect();
			numCorrect++;
		}
		else
		{
			cout << "Sorry, the answer is ";
			questions[i].showAnswer();
		}

		i++;

		getline(cin, controlString, '\n');
	}

	return numCorrect;
}

/*----------------------*/
int Quiz::getLength()
{
	return questions.size();
}
