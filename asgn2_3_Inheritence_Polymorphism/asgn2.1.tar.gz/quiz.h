#ifndef QUIZ_H
#define QUIZ_H

/*
Author: Alex Novitchkov
File: quiz.h, contains the function prototypes of the class Quiz
CS202-01 asgn2.1
Special compiler options: -c -o
Date: 1/30/20

This file contains the function prototypes and
the instance variable of the class Quiz
 */

#include <string>
#include <vector>
#include "question.h"

using namespace std;

class Quiz
{
	public:
		Quiz();

		/*
		   Loads all question in the file to private member questions

		   @param dataFileName, fileName string to parse data from
		   @return bool whether file was opened successfully
		 */
		bool loadQuestions(string dataFileName);

		/*
		   Dumps questions onto the console
		 */
		void dumpQuestions();

		/*
		   Delivers the quiz to the console for user interaction

		   @return number of questions answer correctly
		 */
		int deliverQuiz();

		/*
		   Gets the length of the questions container

		   @return length of questions container
		 */
		int getLength();
	private:
		vector<Question> questions;
};

#endif
