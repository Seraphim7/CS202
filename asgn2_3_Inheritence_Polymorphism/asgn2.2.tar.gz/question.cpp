/*
Author: Alex Novitchkov
File: question.cpp, contains the implementation of the class Question methods
CS202-01 asgn2.2
Special compiler options: -c -o
Date modified: 2/5/20

Contains all Question related class function including the question and answer setters and checkAnswer.
 */

#include <string>
#include <iostream>
#include "question.h"

using namespace std;

/*-------------------*/
Question::Question()
{

}

/*---------------------------------------------------------*/
Question::Question(string questionText, string answerText)
{
	this->questionText = questionText;
	this->answerText = answerText;
	correct = false;
}

/*-------------------------------*/
void Question::showQuestion()
{
	cout << questionText << endl;
}

/*---------------------------------------------*/
bool Question::checkAnswer(string givenAnswer)
{
	if (givenAnswer == answerText)
	{
		correct = true;
		return true;
	}

	correct = false;
	return false;
}

/*---------------------------------------------*/
void Question::setQuestion(string questionText)
{
	this->questionText = questionText;
}

/*-----------------------------------------*/
void Question::setAnswer(string answerText)
{
	this->answerText = answerText;
}

/*---------------------------------*/
void Question::showAnswer()
{
	cout << answerText << "." << endl;
}

/*------------------------------*/
void Question::markCorrect()
{
	if (correct)
	{
		cout << "Correct! Great job!" << endl;
	}
}

/*----------------------------*/
string Question::getQuestion()
{
	return questionText;
}

/*--------------------------*/
string Question::getAnswer()
{
	return answerText;
}

/*-----------------------*/
Question::~Question() {}
