/*
Author: Alex Novitchkov
File: questionTF.cpp, contains implentations of the QuestionTF class
CS202-01 asgn2.2
Special compiler options: -c -o
Date modified: 2/5/20

Contains functions such as showQuestion, showAnswer, checkAnswer, and others
 */

#include <string>
#include "questionTF.h"
#include "question.h"

using namespace std;

/*-------------------------*/
QuestionTF::QuestionTF() {}

/*------------------------------------------------------------*/
QuestionTF::QuestionTF(string questionText, string answerText)
	: Question(questionText, answerText) {}

/*-----------------------------------------------*/
void QuestionTF::setQuestion(string questionText)
{
	Question::setQuestion(questionText);
}

/*--------------------------------------------*/
void QuestionTF::setAnswer(string answerText)
{
	Question::setAnswer(answerText);
}

/*-------------------------------*/
string QuestionTF::getQuestion()
{
	return Question::getQuestion();
}

/*-----------------------------*/
string QuestionTF::getAnswer()
{
	return Question::getAnswer();
}

/*------------------------------*/
void QuestionTF::showQuestion()
{
	Question::showQuestion();
}

/*----------------------------*/
void QuestionTF::showAnswer()
{
	Question::showAnswer();
}

/*-----------------------------------------------*/
bool QuestionTF::checkAnswer(string givenAnswer)
{
	unsigned int lengthOfWordTrue = 4;
	unsigned int lengthOfWordFalse = 5;

	if (givenAnswer.size() == 1)
	{	
		if (givenAnswer[0] == 'T' || givenAnswer[0] == 't')
		{
			givenAnswer = "True";
		}
		else if (givenAnswer[0] == 'F' || givenAnswer[0] == 'f')
		{
			givenAnswer = "False";
		}
	}
	else if (givenAnswer.size() == lengthOfWordTrue)
	{
		if (givenAnswer[0] == 'T' || givenAnswer[0] == 't')
		{
			if (givenAnswer[1] == 'R' || givenAnswer[1] == 'r')
			{
				if (givenAnswer[2] == 'U' || givenAnswer[2] == 'u')
				{
					if (givenAnswer[3] == 'E' || givenAnswer[3] == 'e')
					{
						givenAnswer = "True";
					}
				}
			}
		}
	}
	else if (givenAnswer.size() == lengthOfWordFalse)
	{
		if (givenAnswer[0] == 'F' || givenAnswer[0] == 'f')
		{
			if (givenAnswer[1] == 'A' || givenAnswer[1] == 'a')
			{
				if (givenAnswer[2] == 'L' || givenAnswer[2] == 'l')
				{
					if (givenAnswer[3] == 'S' || givenAnswer[3] == 's')
					{
						if (givenAnswer[4] == 'E' || givenAnswer[4] == 'e')
						{
							givenAnswer = "False";
						}
					}
				}
			}
		}
	}

	return Question::checkAnswer(givenAnswer);
}
