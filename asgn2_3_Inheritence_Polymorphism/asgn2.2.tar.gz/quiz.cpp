/*
Author: Alex Novitchkov
File: quiz.cpp, implementation of the functions defined in the Quiz class
CS202-01 asgn2.2
Special compiler options: -c -o
Date modified: 2/5/20

implementation of all the Quiz class functions
including deliverQuiz and loadQuestions
 */

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include "quiz.h"
#include "question.h"
#include "questionTF.h"
#include "questionMC.h"

using namespace std;

/*-----------------------*/
Quiz::Quiz()
{

}

/*---------------------------------------------*/
bool Quiz::loadQuestions(string dataFileName)
{
	ifstream fin;
	char type;
	string questionText;
	string answerText;
	char correctAnswerLetter;
	string fileLine;
	string tmp;

	fin.open(dataFileName.c_str()); // has to take in a cString equivelant

	int count;

	if (fin.is_open())
	{
		while (getline(fin, fileLine))
		{
			count = 0;

			/* stringParse acts like cin */
			istringstream stringParse(fileLine);

			while (getline(stringParse, tmp, '|'))
			{
				count++;

				if (count == 1)
				{
					type = tmp[0];
				}
				else if (count == 3)
				{
					questionText = tmp;
				}
				else if (count == 4)
				{
					answerText = tmp;
				}
				else if (count == 5)
				{
					correctAnswerLetter = tmp[0];
				}
			}

			if (type == 'S' || type == 's')
			{
				questionText = questionText + "?";

				Question* question = new Question(questionText, answerText);
				questions.push_back(question);
			}
			else if (type == 'T' || type == 't')
			{
				questionText = questionText + ". (True or False?)";

				QuestionTF* question = new QuestionTF(questionText, answerText);
				questions.push_back(question);
			}
			else if (type == 'M' || type == 'm')
			{
				questionText = questionText + "?";

				QuestionMC* question = new QuestionMC(questionText, answerText, correctAnswerLetter);
				questions.push_back(question);
			}
		}

		fin.close();
	}
	else
	{
		cerr << "ERROR while opening file: " << dataFileName << endl;
		return false;
	}

	return true;
}

/*------------------------------*/
void Quiz::dumpQuestions()
{
	if (questions.empty())
	{
		cerr << "No questions given" << endl;
	}
	else
	{
		for (unsigned int i = 0; i < questions.size(); i++)
		{
			cout << endl;
			questions[i]->showQuestion();
			questions[i]->showAnswer();
		}
	}
}

/*-------------------------------*/
int Quiz::deliverQuiz()
{
	int numCorrect = 0;
	int total = questions.size();
	int i = 0;
	string givenAnswer;
	bool correct;
	string controlString;

	cout << endl;

	while (i < total)
	{
		questions[i]->showQuestion();

		getline(cin, givenAnswer);

		correct = questions[i]->checkAnswer(givenAnswer);

		if (correct)
		{
			questions[i]->markCorrect();
			numCorrect++;
		}
		else
		{
			cout << "Sorry, that is incorrect. The answer is ";
			questions[i]->showAnswer();
		}

		i++;

		getline(cin, controlString, '\n');
	}

	return numCorrect;
}

/*----------------------*/
int Quiz::getLength()
{
	return questions.size();
}

/*--------------*/
Quiz::~Quiz()
{
	for (int i = 0; i < getLength(); i++)
	{	
		delete questions.at(i);
	}
	questions.clear();
}
